//MC100401907

//Add Required Packages
import java.util.*;
import java.io.*;

//Create the main class which will read the file and use Student class
public class Driver
{
	//Main Method
	public static void main(String [] args) throws IOException
	{
		//Declare BufferedReader object to read file
		BufferedReader br = null;
		//ArrayList collection object to store students
		ArrayList studentsList = new ArrayList();
		//String array to store different token of a line
		String tokens[] = null;
		//Variables to hold tokens values
		String rn,name,sclass,phno,prg;
		//Variables to hold different counts
		int charCnt=0,spCnt=0,wdCnt=0,lnCnt=0,alpCnt=0,intCnt=0;
		try{
			//Created BufferedReader object by providing file name
			br=new BufferedReader(new FileReader("students.txt"));

			System.out.println("FILE DATA:\n\n");
			//Read First Line
			String line = br.readLine();

			//Check if line is null or not
			while (line != null)
			{
				//Lines Count
				lnCnt++;

				System.out.println(line);

				//Split the line by comma to get different tokens
				tokens = line.split(",");

				name = tokens[0];
				rn = tokens[1];
				sclass = tokens[2];
				phno = tokens[3];
				prg = tokens[4];

				//Create Student Object
				Student std = new Student(rn,name,sclass,phno,prg);
				//Add to list
				studentsList.add(std);

				charCnt += line.length();
				wdCnt += tokens.length;
				wdCnt += name.split(" ").length - 1;

				//Loop to count digits/alphabets/whitespaces
				for (int i = 0, len = line.length(); i < len; i++) {
					if (Character.isDigit(line.charAt(i))) {
						intCnt++;
					}
					else if (Character.isLetter(line.charAt(i))) {
						alpCnt++;
					}
					else if (Character.isWhitespace(line.charAt(i))) {
						spCnt++;
					}
				}
				//Get Next line from reader
				line = br.readLine();
			}
			//Printout a Total studetns count
			System.out.println("\n	Total No of Students:" + Student.getStudentsCount() + "\n");
			Student std;
			//Print out all students in tabluar format
			for(int i=0; i<studentsList.size(); i++)
			{
				std = (Student)studentsList.get(i);
				System.out.println("		Student " + (i+1) + "'s Record");
				System.out.println(std.toString());
				System.out.println("\n");
			}

			System.out.println("		FILE RECORD:\n\n");

			//print out counts
			String data = "_________________________________________________________________________\n";
			data += "|T-Char  |T-Spaces  |T-Words  |T-Lines  |T-Alphabets  |T-Integers\n";
			data += "_________________________________________________________________________\n";
			data += charCnt + "  	  " + spCnt +"  	    "+ wdCnt+"  	   "+ lnCnt +"  	 " + alpCnt+ "  	  	" +intCnt +"\n";
			data += "------------------------------------------------------------------------\n";
			System.out.println(data);

		}catch(IOException ex)
		{
			System.out.println(ex.toString());
		}
		finally
		{
			//Check and close bufferedreader
			if(br != null)
				br.close();
		}

	}
}