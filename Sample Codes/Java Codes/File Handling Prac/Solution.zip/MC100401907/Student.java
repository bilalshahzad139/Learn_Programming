//MC100401907

import java.util.*;

public class Student
{
	//Create Private data members
	private String rollNo;
	private String name;
	private String sclass;
	private String phno;
	private String program;
	public static int stdCount=0;

	//Create Constructors
	public Student()
	{
		stdCount++;
	}
	public Student(String rno,String sn,String cl,String pn,String prg)
	{
		this.rollNo = rno;
		this.name = sn;
		this.sclass= cl;
		this.phno = pn;
		this.program = prg;
		stdCount++;
	}
	//Get Total Students Count
	public static int getStudentsCount()
	{
		return stdCount;
	}
	//Getter Setters
	public void setRollNo(String rno)
	{
		this.rollNo = rno;
	}
	public String getRollNo()
	{
		return this.rollNo;
	}

	public void setName(String sn)
	{
		this.name = sn;
	}
	public String getName()
	{
		return this.name;
	}
	public void setStudClass(String cl)
	{
		this.sclass = cl;
	}
	public String getStudClass()
	{
		return this.sclass;
	}

	public void setPhoneNo(String pn)
	{
		this.phno = pn;
	}
	public String getPhoneNo()
	{
		return this.phno;
	}

	public void setProgram(String prg)
	{
		this.program = prg;
	}
	public String getProgram()
	{
		return this.program;
	}
	//Override toString method
	public String toString()
	{
		String data = "";
		data = "_________________________________________________________________________\n";
		data += "|S-Name		|S-Roll No	|S-Class	|S-PhoneNo	|S-Program\n";
		data += "_________________________________________________________________________\n";
		data += this.name + "		" + this.rollNo +"	"+ this.sclass+"	"+ this.phno +"	" + this.program +"\n";
		data += "------------------------------------------------------------------------\n";
		return data;
	}
	//override finalize method
	public void finalize()
	{
		stdCount--;
	}


}