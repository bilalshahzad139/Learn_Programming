//Student ID # MC100401907
package PCMS.DAL;

import java.sql.*;

//This class is generic class to handle DB interactions from Data Access Layers
public class DBHandler {
        private Connection con = null;
        
        //Function to open a connection
        public Boolean OpenConnection() throws Exception
        {
		try
		{
			Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
                        con = DriverManager.getConnection("jdbc:odbc:productDSN");
                        if(con == null)
                            return false;
                        else
                            return true;
		}
	  	catch (Exception ex)
	  	{
                    return false;
		}
	}
        //Function to close a connection
	public Boolean CloseConnection() throws Exception
	{
		try
		{
			if(con != null)
				con.close();
                        return true;
		}catch(Exception ex)
		{
                    throw new Exception(ex);
		}
	}
        
        //Select queries
	public ResultSet ExecuteQuery(String sqlQuery) throws Exception
	{
            try
            {
                    //Create Statement
                    Statement st = con.createStatement();

                    //Execute Query
                    ResultSet rs = st.executeQuery(sqlQuery);

                    return rs;
            }
            catch (Exception ex)
            {
                throw new Exception(ex);
            }
	}
        //Insert query
	public int InsertQuery(String sqlQuery) throws Exception
	{
            //Create Statement			
            Statement stmt = con.createStatement();
            
            //Execute Query
            int id = stmt.executeUpdate(sqlQuery);
            return id;
	}
        //For update query
	public int UpdateQuery(String sqlQuery) throws Exception
	{
            //Create Statement			
            Statement stmt = con.createStatement();
            
            //Execute Query
            int id = stmt.executeUpdate(sqlQuery);
            return id;
	}
        //For delete query
	public int DeleteQuery(String sqlQuery) throws Exception
	{
            //Create Statement                
            Statement stmt = con.createStatement();

            //Execute Query                
            int delCount = stmt.executeUpdate(sqlQuery);
            return delCount;
	}
}
