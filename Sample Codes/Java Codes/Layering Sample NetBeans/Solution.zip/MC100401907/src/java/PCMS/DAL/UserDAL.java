//Student ID # MC100401907

package PCMS.DAL;

import java.sql.*;


//Class for User related operations e.g. Login Verification
public class UserDAL{
    
        private DBHandler dbObj = null;
        
        public UserDAL()
	{
            dbObj = new DBHandler();
	}
        
	//Check login data
	public Boolean VerifyLogin(String username,String password) throws Exception
	{
		try{
                    
                    
                    Boolean flag = false;
                    if(dbObj.OpenConnection() == true)
                    {
                        
                        String sqlQuery = "SELECT * FROM admin WHERE userName='" + username +"' and password='"+ password +"'";

                        
                        ResultSet rs = dbObj.ExecuteQuery(sqlQuery);
                        
                        if(rs != null && rs.next())
                        {
                            flag = true;
                        }

                    }//End of If
                    return flag;
                     
		}
		catch(Exception ex)
		{			
                    throw new Exception(ex);
		}
		finally
		{
                    dbObj.CloseConnection();
		}
	}//End of VerifyLogin
}//UserDAL