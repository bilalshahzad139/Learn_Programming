//Student ID # MC100401907
package PCMS.Entities;
import java.util.*;

//Class to hold product object
public class ProductDTO
{
	private long ID;
	private String ProductName;
	private String Category;
	private String Price;
	private String Availability;
	private String Quantity;
	private String Description;

        public ProductDTO(){
        
        }
        public ProductDTO(String pname,String cat,String pr,String av,String qt,String desc)
        {
            
            this.ProductName = pname;
            this.Category = cat;
            this.Price = pr;
            this.Availability = av;
            this.Quantity = qt;
            this.Description = desc;
        }
        
        public void SetID(long id)
        {
            this.ID = id;
        }
        public void SetProductName(String pn)
        {
            this.ProductName = pn;
        }
        public void SetCategory(String c)
        {
            this.Category = c;
        }
        public void SetPrice(String p)
        {
            this.Price = p;
        }
        public void SetAvailability(String av)
        {
            this.Availability = av;
        }
        public void SetQuantity(String qt)
        {
            this.Quantity = qt;
        }
        public void SetDescription(String desc)
        {
            this.Description = desc;
        }
        
        public long GetID()
        {
            return this.ID;
        }
        public String GetProductName()
        {
            return this.ProductName;
        }
        public String GetCategory()
        {
            return this.Category;
        }
        public String GetPrice()
        {
            return this.Price;
        }
        public String GetAvailability()
        {
            return this.Availability;
        }
        public String GetQuantity()
        {
            return this.Quantity ;
        }
        public String GetDescription()
        {
            return this.Description ;
        }
}

