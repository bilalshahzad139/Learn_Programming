//Student ID # MC100401907
package PCMS.DAL;

import java.sql.*;
import java.util.*;
import PCMS.Entities.*;

//Class to handle database operations
public class ProductDAL{

	private DBHandler dbObj = null;
	public ProductDAL()
	{
            dbObj = new DBHandler();
	}
	
	//Save product
	public Boolean SaveProduct(ProductDTO prod) throws Exception
	{
		try{
                    //OEPN CONNECTION     
                    if(dbObj.OpenConnection() == true)
                    {
                        String query = "INSERT INTO product(productName, category, price, availability, quantity, description) Values('"+prod.GetProductName()+"','"+prod.GetCategory()+"','"+prod.GetPrice()+"','"+prod.GetAvailability()+"','"+prod.GetQuantity()+"','"+prod.GetDescription()+"')";
			int cnt = dbObj.InsertQuery(query);
                      
                        if(cnt > 0)
                            return true;
                        else 
                            return false;
                    }
                    
                    return false;
		}
		catch(Exception ex)
		{			
                    throw new Exception(ex);
		}
		finally
		{
                    dbObj.CloseConnection();
		}

	}//End of SaveProduct
               
        //GetAllProducts
	public List<ProductDTO> GetAllProducts() throws Exception
	{
		try{
                    List<ProductDTO> products = new ArrayList<ProductDTO>();
                    if(dbObj.OpenConnection() == true)
                    {
                        String query = "Select * from product order by id desc";
			ResultSet rs = dbObj.ExecuteQuery(query);
                       
                        ProductDTO dto = null;
                       
                        while(rs.next())
                        {
                            long ID = rs.getLong("Id");
                            String prodName = rs.getString("productName");
                            String prodCat = rs.getString("category");
                            String price = rs.getString("price");
                            String available = rs.getString("availability");
                            String quantity = rs.getString("quantity");
                            String descript = rs.getString("description");
                                                        
                            dto = new ProductDTO(prodName,prodCat,price,available,quantity,descript);
                            dto.SetID(ID);
                            
                            products.add(dto);
                        }//end of while
                    }//end of if
                    
                    return products;
		}
		catch(Exception ex)
		{			
                    throw new Exception(ex);
		}
		finally
		{
                    dbObj.CloseConnection();
		}

	}//End of GetAllProducts

        //Delete product
	public Boolean DeleteProduct(String [] prodIds) throws Exception
	{
		try{
                        
                    if(dbObj.OpenConnection() == true)
                    {
                        
                        String ids= "";
                        for (int i = 0; i < prodIds.length; i++) 
                        {
                            if(i== prodIds.length-1)
                                ids = ids + prodIds[i];
                            else
                                ids = ids + prodIds[i] + ",";
                        }
                                                
                        String query = "Delete From product where ID IN("+ ids+")";
			int cnt = dbObj.DeleteQuery(query);
                      
                        if(cnt > 0)
                            return true;
                        else 
                            return false;
                    }
                    
                    return false;
		}
		catch(Exception ex)
		{			
                    throw new Exception(ex);
		}
		finally
		{
                    dbObj.CloseConnection();
		}

	}//End of Delete product
	
}